-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: cms
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `category` varchar(200) DEFAULT NULL,
  `price` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (7,'Margherita','Pizza','249'),(8,'Corn & Cheese','Pizza','289'),(9,'Farmhouse','Pizza','269'),(10,'Peppy Paneer','Pizza','289'),(11,'Mexican Green Wave','Pizza','457'),(12,'Creamy Tomato','Pizza','499'),(13,'Moroccan Spice','Pizza','199'),(14,'Paneer Tikka','Starters','300'),(15,'Tandoori Brocolli','Starters','470'),(16,'Cheese Grilled','Sandwiches','150'),(17,'Veggie Grilled','Sandwiches','170'),(18,'Garlic Chilli Cheese','Sandwiches','179'),(19,'Sweet Corn','Soups','160'),(20,'Hot & Sour','Soups','150'),(21,'Manchow','Soups','199'),(23,'Creamy Tomato','Soups','149'),(24,'Cashew Brig','Desserts & Beverages','185'),(25,'Choco Crunch','Desserts & Beverages','249'),(26,'Kesar Thandai','Desserts & Beverages','149'),(27,'Moose Tracks','Desserts & Beverages','349'),(28,'Mysore Masala Dosa','South Indian','179'),(29,'Masala Uttapam','South Indian','159'),(30,'Crispy Schezwan Dosa','South Indian','199'),(31,'Grilled Idli Tikka','South Indian','399'),(32,'Chinese Bhel','Chinese','299'),(33,'Veg Spring Roll','Chinese','279'),(34,'Paneer Manchurian','Chinese','299'),(35,'Shanghai Paneer','Chinese','250'),(36,'Cheese Garlic Bread','Quick Bites','199'),(37,'French Fries','Quick Bites','149'),(38,'Crispy Chilli Babycorn','Quick Bites','349'),(41,'Cheese Babycorn','Pizza','399'),(42,'Garlic Bread','Breads','199'),(44,'Green Tea','Tea','35'),(45,'Black Tea','Tea','20'),(46,'Orange','Juice','50');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-25 18:57:39

-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: cms
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill` (
  `id` int NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `mobileNumber` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `total` varchar(200) DEFAULT NULL,
  `createdBy` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill`
--

LOCK TABLES `bill` WRITE;
/*!40000 ALTER TABLE `bill` DISABLE KEYS */;
INSERT INTO `bill` VALUES (1,'Rishab Dugar','0123456789','rishabdugar@gmail.com','27-07-2022','2940','admin@gmail.com'),(2,'Doraemon','1123456789','doraemon@gmail.com','27-07-2022','6750','null'),(3,'Shizuka Minamoto','9839839839','shizuka@gmail.com','27-07-2022','2250','admin@gmail.com'),(4,'RD','1234567890','rd@gmail.com','27-07-2022','9110','null'),(5,'Nobita Nobi','9898989898','nobita@gmail.com','27-07-2022','550','null'),(6,'Gian ','9898989898','takeshigowda@gmail.com','27-07-2022','24550','nobitanobi7@gmail.com'),(7,'Suneo Honekawa','8787878787','suneo@gmail.com','27-07-2022','2250','nobitanobi7@gmail.com'),(8,'Doraemon','1111111111','doraemon@gmail.com','27-07-2022','550','admin@gmail.com'),(9,'Miyoko Nonohana','9839839839','miyoko@gmail.com','27-07-2022','3161','eiichikite@gmail.com'),(10,'Rishab Dugar','9876543210','rishabdugar@gmail.com','27-07-2022','5400','dekisugi@gmail.com'),(11,'Takeshi Gouda','9876543210','gian@gmail.com','27-07-2022','17157','gian@gmail.com'),(12,'Shizuka ','9876543210','shizuka@nobita.com','27-07-2022','2552','nobita@gmail.com'),(13,'Rishab','9875643210','abcd@gmail.com','28-07-2022','2780','kingrishabdugar@gmail.com'),(14,'Prasan','9876543116','abc@gmail.com','22-08-2022','199','admin@gmail.com'),(15,'abc','1234567890','abc@abc.com','23-08-2022','199','admin@gmail.com'),(16,'Dekisugi','1234567890','dekisugi@gmail.com','23-08-2022','538','admin@gmail.com'),(17,'Nobita','1234567890','abc@nobita.com','23-08-2022','706','nobitanobi7@gmail.com'),(18,'Sayan ','9876543210','sayan@gmail.com','23-08-2022','71484','admin@gmail.com');
/*!40000 ALTER TABLE `bill` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-25 18:57:39
